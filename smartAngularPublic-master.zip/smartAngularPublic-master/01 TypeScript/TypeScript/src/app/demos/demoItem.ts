
export class DemoItem {
    url: string;
    title: string;
    component: string;
}
