export module MathFunctions {
    
        export function square(nbr: number): number {
            return Math.pow(nbr, 2);
        }
}