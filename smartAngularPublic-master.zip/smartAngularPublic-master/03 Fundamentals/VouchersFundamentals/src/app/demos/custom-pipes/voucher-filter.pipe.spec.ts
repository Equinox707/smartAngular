import { VoucherFilterPipe } from './voucher-filter.pipe';

describe('VoucherFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new VoucherFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
