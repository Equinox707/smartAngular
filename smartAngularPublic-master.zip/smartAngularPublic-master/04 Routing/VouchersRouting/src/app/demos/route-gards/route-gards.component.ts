import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route-gards',
  templateUrl: './route-gards.component.html',
  styleUrls: ['./route-gards.component.css']
})
export class RouteGardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
