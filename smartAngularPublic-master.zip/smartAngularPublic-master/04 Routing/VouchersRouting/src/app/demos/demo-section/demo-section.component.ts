import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'demo-section',
  templateUrl: './demo-section.component.html',
  styleUrls: ['./demo-section.component.css']
})
export class DemoSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
