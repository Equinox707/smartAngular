﻿window.onload = function () {
    loadPage('home.htm', null);
}